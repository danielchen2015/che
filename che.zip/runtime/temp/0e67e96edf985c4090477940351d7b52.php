<?php /*a:4:{s:58:"E:\wamp\www\che\application\admin\view\config\setting.html";i:1557279132;s:57:"E:\wamp\www\che\application\admin\view\public\header.html";i:1557328178;s:55:"E:\wamp\www\che\application\admin\view\public\left.html";i:1557328412;s:57:"E:\wamp\www\che\application\admin\view\public\footer.html";i:1557279132;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Mosaddek">
    <meta name="keyword" content="FlatLab, Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
    <link rel="shortcut icon" href="/static/admin/img/favicon.png">

    <title>系统设置</title>

    <!-- Bootstrap core CSS -->
    <link href="/static/admin/css/bootstrap.min.css" rel="stylesheet">
    <link href="/static/admin/css/bootstrap-reset.css" rel="stylesheet">
    <!--external css-->
    <link href="/static/admin/assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <!--right slidebar-->
    <link href="/static/admin/css/slidebars.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="/static/admin/css/style.css" rel="stylesheet">
    <link href="/static/admin/css/style-responsive.css" rel="stylesheet" />

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
    <!--[if lt IE 9]>
    <script src="/static/admin/js/html5shiv.js"></script>
    <script src="/static/admin/js/respond.min.js"></script>
    <![endif]-->
</head>

<body>

<section id="container" class="">
    <!--header start-->
<header class="header white-bg">
    <div class="sidebar-toggle-box">
        <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
    </div>
    <!--logo start-->
    <a href="index.html" class="logo">全国兄弟情<span>精选二手车</span></a>
    <!--logo end-->
    <div class="top-nav ">
        <!--search & user info start-->
        <ul class="nav pull-right top-menu">
            <li>
                <input type="text" class="form-control search" placeholder="Search">
            </li>
            <!-- user login dropdown start-->
            <li class="dropdown">
                <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                    <img alt="" src="/static/admin/img/avatar1_small.jpg">
                    <span class="username"><?php echo htmlentities($username); ?></span>
                    <b class="caret"></b>
                </a>
                <ul class="dropdown-menu extended logout">
                    <div class="log-arrow-up"></div>
                    <li><a href="<?php echo url('User/profile',['id'=>$userid]); ?>"><i class=" fa fa-suitcase"></i>个人中心</a></li>
                    <li><a href="<?php echo url('Config/setting'); ?>"><i class="fa fa-cog"></i> 设置中心</a></li>
                    <li><a href="<?php echo url('Vehicle/lists',['userid'=>$userid]); ?>"><i class="fa fa-bell-o"></i> 我的车辆</a></li>
                    <li><a href="<?php echo url('User/loginOut'); ?>"><i class="fa fa-key"></i>退 出</a></li>
                </ul>
            </li>
            <li class="sb-toggle-right">
                <i class="fa  fa-align-right"></i>
            </li>
            <!-- user login dropdown end -->
        </ul>
        <!--search & user info end-->
    </div>
</header>
<!--header end-->
    <!--sidebar start-->
<aside>
    <div id="sidebar" class="nav-collapse ">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu" id="nav-accordion">
            <li>
                <a class="active" href="index.html">
                    <i class="fa fa-dashboard"></i>
                    <span>导航</span>
                </a>
            </li>

            <li class="sub-menu">
                <a href="javascript:;">
                    <i class="fa fa-laptop"></i>
                    <span>个人中心</span>
                </a>
                <ul class="sub">
                    <li><a href="<?php echo url('User/profile',['id'=>$userid]); ?>">个人中心</a></li>
                </ul>
            </li>

            <li class="sub-menu">
                <a href="javascript:;">
                    <i class="fa fa-laptop"></i>
                    <span>用户管理</span>
                </a>
                <ul class="sub">
                    <li><a href="<?php echo url('User/lists'); ?>">用户管理</a></li>
                </ul>
            </li>

            <li class="sub-menu">
                <a href="javascript:;">
                    <i class="fa fa-book"></i>
                    <span>车辆管理</span>
                </a>
                <ul class="sub">
                    <li><a href="<?php echo url('Vehicle/vlist'); ?>">车辆管理</a></li>
                </ul>
            </li>

            <li class="sub-menu">
                <a href="javascript:;">
                    <i class="fa fa-cogs"></i>
                    <span>系统设置</span>
                </a>
                <ul class="sub">
                    <li><a href="<?php echo url('Config/setting'); ?>">系统设置</a></li>
                </ul>
            </li>

        </ul>
        <!-- sidebar menu end-->
    </div>
</aside>
<!--sidebar end-->
    <!--main content start-->
    <section id="main-content">
        <section class="wrapper">
            <!-- page start-->
            <div class="row">
                <aside class="profile-info col-lg-6">
                    <section class="panel">
                        <div class="bio-graph-heading">
                            系统设置
                        </div>
                        <div class="panel-body bio-graph-info">
                            <h1> 系统设置</h1>
                            <form class="form-horizontal" role="form" action="<?php echo url('Config/settingUpdate'); ?>" method="post">
                                <div class="form-group">
                                    <label  class="col-lg-2 control-label">标题</label>
                                    <div class="col-lg-6">
                                        <input type="text" class="form-control" name="title" placeholder=" " value="<?php echo htmlentities($setting['title']); ?>">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label  class="col-lg-2 control-label">公司名称</label>
                                    <div class="col-lg-6">
                                        <input type="text" class="form-control" placeholder=" " name="company" value="<?php echo htmlentities($setting['company']); ?>">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label  class="col-lg-2 control-label">手机号</label>
                                    <div class="col-lg-6">
                                        <input type="text" class="form-control" name="mobile" placeholder=" " value="<?php echo htmlentities($setting['mobile']); ?>" maxlength="11">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label  class="col-lg-2 control-label">联系方式</label>
                                    <div class="col-lg-6">
                                        <input type="text" class="form-control" name="telno" placeholder=" " value="<?php echo htmlentities($setting['telno']); ?>">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label  class="col-lg-2 control-label">微信二维码</label>
                                    <div class="col-lg-6">
                                        <input type="text" class="form-control" name="weixinimg" placeholder=" " value="<?php echo htmlentities($setting['weixinimg']); ?>">
                                    </div>
                                </div>


                                <div class="form-group">
                                    <label  class="col-lg-2 control-label">广告位图片</label>
                                    <div class="col-lg-6">
                                        <input type="text" class="form-control" name="adimgs" placeholder=" " value="<?php echo htmlentities($setting['adimgs']); ?>">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="col-lg-offset-2 col-lg-10">
                                        <button type="submit" class="btn btn-success">保存</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </section>
                </aside>
            </div>

            <!-- page end-->
        </section>
    </section>
    <!--main content end-->

    <!--footer start-->
<footer class="site-footer">
    <div class="text-center">
        2019 &copy; 上海雅速企业管理咨询有限公司 技术支持
        <a href="#" class="go-top">
            <i class="fa fa-angle-up"></i>
        </a>
    </div>
</footer>
<!--footer end-->
</section>

<!-- js placed at the end of the document so the pages load faster -->
<script src="/static/admin/js/jquery.js"></script>
<script src="/static/admin/js/bootstrap.min.js"></script>
<script class="include" type="text/javascript" src="/static/admin/js/jquery.dcjqaccordion.2.7.js"></script>
<script src="/static/admin/js/jquery.scrollTo.min.js"></script>
<script src="/static/admin/js/jquery.nicescroll.js" type="text/javascript"></script>
<script src="/static/admin/assets/jquery-knob//static/admin/js/jquery.knob.js"></script>
<script src="/static/admin/js/respond.min.js" ></script>

<!--right slidebar-->
<script src="/static/admin/js/slidebars.min.js"></script>

<!--common script for all pages-->
<script src="/static/admin/js/common-scripts.js"></script>

<script>

    //knob
    $(".knob").knob();

</script>


</body>
</html>
