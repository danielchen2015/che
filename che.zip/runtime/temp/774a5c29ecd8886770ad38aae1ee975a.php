<?php /*a:1:{s:54:"E:\wamp\www\che\application\admin\view\user\login.html";i:1557328178;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Mosaddek">
    <meta name="keyword" content="FlatLab, Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
    <link rel="shortcut icon" href="/static/admin/img/favicon.png">

    <title>全国兄弟情精选车管理后台</title>

    <!-- Bootstrap core CSS -->
    <link href="/static/admin/css/bootstrap.min.css" rel="stylesheet">
    <link href="/static/admin/css/bootstrap-reset.css" rel="stylesheet">
    <!--external css-->
    <link href="/static/admin/assets/font-awesome/css/font-awesome.css" rel="stylesheet"/>
    <!-- Custom styles for this template -->
    <link href="/static/admin/css/style.css" rel="stylesheet">
    <link href="/static/admin/css/style-responsive.css" rel="stylesheet"/>

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
    <!--[if lt IE 9]>
    <script src="/static/admin/js/html5shiv.js"></script>
    <script src="/static/admin/js/respond.min.js"></script>
    <![endif]-->
</head>

<body class="login-body">

<div class="container">

    <form class="form-signin" action="<?php echo url('User/login'); ?>" method="post">
        <h2 class="form-signin-heading">管理后台</h2>
        <div class="login-wrap">
            <input type="text" class="form-control" placeholder="用户名" autofocus name="username">
            <input type="password" class="form-control" placeholder="密码" name="password">

            <button class="btn btn-lg btn-login btn-block" type="submit">登 陆</button>

        </div>

    </form>

</div>


<!-- js placed at the end of the document so the pages load faster -->
<script src="/static/admin/js/jquery.js"></script>
<script src="/static/admin/js/bootstrap.min.js"></script>


</body>
</html>