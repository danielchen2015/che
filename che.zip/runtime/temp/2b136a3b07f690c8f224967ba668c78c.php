<?php /*a:4:{s:56:"E:\wamp\www\che\application\admin\view\vehicle\list.html";i:1557409572;s:57:"E:\wamp\www\che\application\admin\view\public\header.html";i:1557328178;s:55:"E:\wamp\www\che\application\admin\view\public\left.html";i:1557328412;s:57:"E:\wamp\www\che\application\admin\view\public\footer.html";i:1557279132;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Mosaddek">
    <meta name="keyword" content="车辆列表">
    <link rel="shortcut icon" href="img/favicon.png">

    <title>车辆列表</title>

    <!-- Bootstrap core CSS -->
    <link href="/static/admin/css/bootstrap.min.css" rel="stylesheet">
    <link href="/static/admin/css/bootstrap-reset.css" rel="stylesheet">
    <!--external css-->
    <link href="/static/admin/assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <!--right slidebar-->
    <link href="/static/admin/css/slidebars.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="/static/admin/css/style.css" rel="stylesheet">
    <link href="/static/admin/css/style-responsive.css" rel="stylesheet" />

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
    <!--[if lt IE 9]>
    <script src="/static/admin/js/html5shiv.js"></script>
    <script src="/static/admin/js/respond.min.js"></script>
    <![endif]-->
</head>

<body>

<section id="container" class="">
    <!--header start-->
<header class="header white-bg">
    <div class="sidebar-toggle-box">
        <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
    </div>
    <!--logo start-->
    <a href="index.html" class="logo">全国兄弟情<span>精选二手车</span></a>
    <!--logo end-->
    <div class="top-nav ">
        <!--search & user info start-->
        <ul class="nav pull-right top-menu">
            <li>
                <input type="text" class="form-control search" placeholder="Search">
            </li>
            <!-- user login dropdown start-->
            <li class="dropdown">
                <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                    <img alt="" src="/static/admin/img/avatar1_small.jpg">
                    <span class="username"><?php echo htmlentities($username); ?></span>
                    <b class="caret"></b>
                </a>
                <ul class="dropdown-menu extended logout">
                    <div class="log-arrow-up"></div>
                    <li><a href="<?php echo url('User/profile',['id'=>$userid]); ?>"><i class=" fa fa-suitcase"></i>个人中心</a></li>
                    <li><a href="<?php echo url('Config/setting'); ?>"><i class="fa fa-cog"></i> 设置中心</a></li>
                    <li><a href="<?php echo url('Vehicle/lists',['userid'=>$userid]); ?>"><i class="fa fa-bell-o"></i> 我的车辆</a></li>
                    <li><a href="<?php echo url('User/loginOut'); ?>"><i class="fa fa-key"></i>退 出</a></li>
                </ul>
            </li>
            <li class="sb-toggle-right">
                <i class="fa  fa-align-right"></i>
            </li>
            <!-- user login dropdown end -->
        </ul>
        <!--search & user info end-->
    </div>
</header>
<!--header end-->
    <!--sidebar start-->
<aside>
    <div id="sidebar" class="nav-collapse ">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu" id="nav-accordion">
            <li>
                <a class="active" href="index.html">
                    <i class="fa fa-dashboard"></i>
                    <span>导航</span>
                </a>
            </li>

            <li class="sub-menu">
                <a href="javascript:;">
                    <i class="fa fa-laptop"></i>
                    <span>个人中心</span>
                </a>
                <ul class="sub">
                    <li><a href="<?php echo url('User/profile',['id'=>$userid]); ?>">个人中心</a></li>
                </ul>
            </li>

            <li class="sub-menu">
                <a href="javascript:;">
                    <i class="fa fa-laptop"></i>
                    <span>用户管理</span>
                </a>
                <ul class="sub">
                    <li><a href="<?php echo url('User/lists'); ?>">用户管理</a></li>
                </ul>
            </li>

            <li class="sub-menu">
                <a href="javascript:;">
                    <i class="fa fa-book"></i>
                    <span>车辆管理</span>
                </a>
                <ul class="sub">
                    <li><a href="<?php echo url('Vehicle/vlist'); ?>">车辆管理</a></li>
                </ul>
            </li>

            <li class="sub-menu">
                <a href="javascript:;">
                    <i class="fa fa-cogs"></i>
                    <span>系统设置</span>
                </a>
                <ul class="sub">
                    <li><a href="<?php echo url('Config/setting'); ?>">系统设置</a></li>
                </ul>
            </li>

        </ul>
        <!-- sidebar menu end-->
    </div>
</aside>
<!--sidebar end-->
    <!--main content start-->
    <section id="main-content">
        <section class="wrapper">
            <!-- page start-->
            <div class="row">
                <div class="col-lg-12">
                    <section class="panel">
                        <header class="panel-heading">
                            Advanced Table
                        </header>
                        <table class="table table-striped table-advance table-hover">
                            <thead>
                            <tr>
                                <th><i class="fa fa-bullhorn"></i> id</th>
                                <th class="hidden-phone"><i class="fa fa-question-circle"></i> 车辆名称</th>
                                <th><i class="fa fa-bookmark"></i> 出厂时间</th>
                                <th><i class=" fa fa-edit"></i> 车辆状态</th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>
                             <?php foreach($vehiclelist as $key =>$value){
                             echo '<tr>
                                    <td><a href="#">'.$value['id'].'</a></td>
                                    <td class="hidden-phone">'.$value['modessls'].'</td>
                                    <td>'.$value['price'].'</td>
                                    <td><span class="label label-info label-mini">Due</span></td>
                                    <td>
                                        <a class="btn btn-success btn-sm" href="/admin/vehicle/vehicleinfo?id='.$value['id'].'"><i class="fa fa-fw fa-edit"></i></a>
                                        <button class="btn btn-primary btn-sm"><i class="fa fa-pencil"></i></button>
                                        <button class="btn btn-danger btn-sm"><i class="fa fa-trash-o "></i></button>
                                    </td>
                                </tr>';
                              }
                             ?>
                            </tbody>
                        </table>
                    </section>
                </div>
            </div>
            <!-- page end-->
        </section>
    </section>

    <!--footer start-->
<footer class="site-footer">
    <div class="text-center">
        2019 &copy; 上海雅速企业管理咨询有限公司 技术支持
        <a href="#" class="go-top">
            <i class="fa fa-angle-up"></i>
        </a>
    </div>
</footer>
<!--footer end-->
</section>

<!-- js placed at the end of the document so the pages load faster -->
<script src="/static/admin/js/jquery.js"></script>
<script src="/static/admin/js/bootstrap.min.js"></script>
<script class="include" type="text/javascript" src="/static/admin/js/jquery.dcjqaccordion.2.7.js"></script>
<script src="/static/admin/js/jquery.scrollTo.min.js"></script>
<script src="/static/admin/js/jquery.nicescroll.js" type="text/javascript"></script>
<script src="/static/admin/js/respond.min.js" ></script>

<!--right slidebar-->
<script src="/static/admin/js/slidebars.min.js"></script>

<!--common script for all pages-->
<script src="/static/admin/js/common-scripts.js"></script>
<script type="text/javascript">
    $(function(){
        $(".fa-check").click(function () {
            
        })
    })
</script>

</body>
</html>
