<?php /*a:4:{s:63:"E:\wamp\www\che\application\admin\view\vehicle\vehicleinfo.html";i:1557412287;s:57:"E:\wamp\www\che\application\admin\view\public\header.html";i:1557328178;s:55:"E:\wamp\www\che\application\admin\view\public\left.html";i:1557328412;s:57:"E:\wamp\www\che\application\admin\view\public\footer.html";i:1557279132;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Mosaddek">
    <meta name="keyword" content="FlatLab, Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
    <link rel="shortcut icon" href="img/favicon.png">

    <title>Form Validation</title>

    <!-- Bootstrap core CSS -->
    <link href="/static/admin/css/bootstrap.min.css" rel="stylesheet">
    <link href="/static/admin/css/bootstrap-reset.css" rel="stylesheet">
    <!--external css-->
    <link href="/static/admin/assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <!--right slidebar-->
    <link href="/static/admin/css/slidebars.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="/static/admin/css/style.css" rel="stylesheet">
    <link href="/static/admin/css/style-responsive.css" rel="stylesheet" />

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
    <!--[if lt IE 9]>
    <script src="/static/admin/js/html5shiv.js"></script>
    <script src="/static/admin/js/respond.min.js"></script>
    <![endif]-->
</head>

<body>

<section id="container" class="">
    <!--header start-->
<header class="header white-bg">
    <div class="sidebar-toggle-box">
        <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
    </div>
    <!--logo start-->
    <a href="index.html" class="logo">全国兄弟情<span>精选二手车</span></a>
    <!--logo end-->
    <div class="top-nav ">
        <!--search & user info start-->
        <ul class="nav pull-right top-menu">
            <li>
                <input type="text" class="form-control search" placeholder="Search">
            </li>
            <!-- user login dropdown start-->
            <li class="dropdown">
                <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                    <img alt="" src="/static/admin/img/avatar1_small.jpg">
                    <span class="username"><?php echo htmlentities($username); ?></span>
                    <b class="caret"></b>
                </a>
                <ul class="dropdown-menu extended logout">
                    <div class="log-arrow-up"></div>
                    <li><a href="<?php echo url('User/profile',['id'=>$userid]); ?>"><i class=" fa fa-suitcase"></i>个人中心</a></li>
                    <li><a href="<?php echo url('Config/setting'); ?>"><i class="fa fa-cog"></i> 设置中心</a></li>
                    <li><a href="<?php echo url('Vehicle/lists',['userid'=>$userid]); ?>"><i class="fa fa-bell-o"></i> 我的车辆</a></li>
                    <li><a href="<?php echo url('User/loginOut'); ?>"><i class="fa fa-key"></i>退 出</a></li>
                </ul>
            </li>
            <li class="sb-toggle-right">
                <i class="fa  fa-align-right"></i>
            </li>
            <!-- user login dropdown end -->
        </ul>
        <!--search & user info end-->
    </div>
</header>
<!--header end-->
    <!--sidebar start-->
<aside>
    <div id="sidebar" class="nav-collapse ">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu" id="nav-accordion">
            <li>
                <a class="active" href="index.html">
                    <i class="fa fa-dashboard"></i>
                    <span>导航</span>
                </a>
            </li>

            <li class="sub-menu">
                <a href="javascript:;">
                    <i class="fa fa-laptop"></i>
                    <span>个人中心</span>
                </a>
                <ul class="sub">
                    <li><a href="<?php echo url('User/profile',['id'=>$userid]); ?>">个人中心</a></li>
                </ul>
            </li>

            <li class="sub-menu">
                <a href="javascript:;">
                    <i class="fa fa-laptop"></i>
                    <span>用户管理</span>
                </a>
                <ul class="sub">
                    <li><a href="<?php echo url('User/lists'); ?>">用户管理</a></li>
                </ul>
            </li>

            <li class="sub-menu">
                <a href="javascript:;">
                    <i class="fa fa-book"></i>
                    <span>车辆管理</span>
                </a>
                <ul class="sub">
                    <li><a href="<?php echo url('Vehicle/vlist'); ?>">车辆管理</a></li>
                </ul>
            </li>

            <li class="sub-menu">
                <a href="javascript:;">
                    <i class="fa fa-cogs"></i>
                    <span>系统设置</span>
                </a>
                <ul class="sub">
                    <li><a href="<?php echo url('Config/setting'); ?>">系统设置</a></li>
                </ul>
            </li>

        </ul>
        <!-- sidebar menu end-->
    </div>
</aside>
<!--sidebar end-->
    <!--main content start-->
    <section id="main-content">
        <section class="wrapper">
            <!-- page start-->
            <div class="row">
                <div class="col-lg-12">
                    <section class="panel">
                        <header class="panel-heading">
                            Basic validations
                        </header>
                        <div class="panel-body">
                            <form role="form" class="form-horizontal tasi-form">
                                <div class="form-group has-success">
                                    <label class="col-lg-2 control-label">First Name</label>
                                    <div class="col-lg-10">
                                        <input type="text" placeholder="" id="f-name" class="form-control">
                                        <p class="help-block">Successfully done</p>
                                    </div>
                                </div>
                                <div class="form-group has-error">
                                    <label class="col-lg-2 control-label">Last Name</label>
                                    <div class="col-lg-10">
                                        <input type="text" placeholder="" id="l-name" class="form-control">
                                        <p class="help-block">Aha you gave a wrong info</p>
                                    </div>
                                </div>
                                <div class="form-group has-warning">
                                    <label class="col-lg-2 control-label">Email</label>
                                    <div class="col-lg-10">
                                        <input type="email" placeholder="" id="email2" class="form-control">
                                        <p class="help-block">Something went wrong</p>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="col-lg-offset-2 col-lg-10">
                                        <button class="btn btn-danger" type="submit">Submit</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </section>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-12">
                    <section class="panel">
                        <header class="panel-heading">
                            车辆信息数据
                        </header>
                        <div class="panel-body">
                            <div class="form">
                                <form class="cmxform form-horizontal tasi-form" id="signupForm" method="get" action="">
                                    <div class="form-group ">
                                        <label for="firstname" class="control-label col-lg-2">Firstname</label>
                                        <div class="col-lg-10">
                                            <input class=" form-control" id="firstname" name="firstname" type="text" />
                                        </div>
                                    </div>
                                    <div class="form-group ">
                                        <label for="lastname" class="control-label col-lg-2">Lastname</label>
                                        <div class="col-lg-10">
                                            <input class=" form-control" id="lastname" name="lastname" type="text" />
                                        </div>
                                    </div>
                                    <div class="form-group ">
                                        <label for="price" class="control-label col-lg-2">价格</label>
                                        <div class="col-lg-10">
                                            <input class="form-control " id="price" name="data[price]" value="<?=$vehicleinfo['price']?>" type="text" />
                                        </div>
                                    </div>

                                    <div class="form-group ">
                                        <label for="models" class="control-label col-lg-2">车型</label>
                                        <div class="col-lg-10">
                                            <input class="form-control " id="models" name="data[models]" value="<?=$vehicleinfo['models']?>" type="text" />
                                        </div>
                                    </div>
                                    <div class="form-group ">
                                        <label for="boarddateyear" class="control-label col-lg-2">上牌日期年份</label>
                                        <div class="col-lg-10">
                                            <input class="form-control " id="boarddateyear" name="data[boarddateyear]" value="<?=$vehicleinfo['boarddateyear']?>" type="text" />
                                        </div>
                                    </div>
                                    <div class="form-group ">
                                        <label for="boarddatemonth" class="control-label col-lg-2">上牌日期月份</label>
                                        <div class="col-lg-10">
                                            <input class="form-control " id="boarddatemonth" name="data[boarddatemonth]" value="<?=$vehicleinfo['boarddatemonth']?>" type="text" />
                                        </div>
                                    </div>
                                    <div class="form-group ">
                                        <label for="proddateyear" class="control-label col-lg-2">出厂日期年份</label>
                                        <div class="col-lg-10">
                                            <input class="form-control " id="proddateyear" name="data[proddateyear]" value="<?=$vehicleinfo['proddateyear']?>" type="text" />
                                        </div>
                                    </div>
                                    <div class="form-group ">
                                        <label for="proddatemonth" class="control-label col-lg-2">出厂日期月份</label>
                                        <div class="col-lg-10">
                                            <input class="form-control " id="proddatemonth" name="data[proddatemonth]" value="<?=$vehicleinfo['proddatemonth']?>" type="text" />
                                        </div>
                                    </div>
                                        <div class="form-group ">
                                        <label for="realmileage" class="control-label col-lg-2">真实里程</label>
                                        <div class="col-lg-10">
                                            <input class="form-control " id="realmileage" name="data[realmileage]" value="<?=$vehicleinfo['realmileage']?>" type="text" />
                                        </div>
                                    </div>
                                        <div class="form-group ">
                                        <label for="condition" class="control-label col-lg-2">车况描述</label>
                                        <div class="col-lg-10">
                                            <input class="form-control " id="condition" name="data[condition]" value="<?=$vehicleinfo['condition']?>" type="text" />
                                        </div>
                                    </div>
                                    <div class="form-group ">
                                        <label for="contacttel" class="control-label col-lg-2">联系电话</label>
                                        <div class="col-lg-10">
                                            <input class="form-control " id="contacttel" name="data[contacttel]" value="<?=$vehicleinfo['contacttel']?>" type="text" />
                                        </div>
                                    </div>
                                    <div class="form-group ">
                                        <label for="guideprice" class="control-label col-lg-2">新车指导价</label>
                                        <div class="col-lg-10">
                                            <input class="form-control " id="guideprice" name="data[guideprice]" value="<?=$vehicleinfo['guideprice']?>" type="text" />
                                        </div>
                                    </div>
                                    <div class="form-group ">
                                        <label for="displacement" class="control-label col-lg-2">汽车排量</label>
                                        <div class="col-lg-10">
                                            <input class="form-control " id="displacement" name="data[displacement]" value="<?=$vehicleinfo['displacement']?>" type="text" />
                                        </div>
                                    </div>


                                    <div class="form-group ">
                                        <label for="configuration" class="control-label col-lg-2">车辆配置</label>
                                        <div class="col-lg-10">
                                            <input class="form-control " id="configuration" name="data[configuration]" value="<?=$vehicleinfo['configuration']?>" type="text" />
                                        </div>
                                    </div>
                                    <div class="form-group ">
                                        <label for="loc_province" class="control-label col-lg-2">车辆所在地省份</label>
                                        <div class="col-lg-10">
                                            <input class="form-control " id="loc_province" name="data[loc_province]" value="<?=$vehicleinfo['loc_province']?>" type="text" />
                                        </div>
                                    </div>
                                    <div class="form-group ">
                                        <label for="loc_city" class="control-label col-lg-2">车辆所在地城市</label>
                                        <div class="col-lg-10">
                                            <input class="form-control " id="loc_city" name="data[loc_city]" value="<?=$vehicleinfo['loc_city']?>" type="text" />
                                        </div>
                                    </div>
                                    <div class="form-group ">
                                        <label for="loc_area" class="control-label col-lg-2">车辆所在地区域</label>
                                        <div class="col-lg-10">
                                            <input class="form-control " id="loc_area" name="data[loc_area]" value="<?=$vehicleinfo['loc_area']?>" type="text" />
                                        </div>
                                    </div>

                                    <div class="form-group ">
                                        <label for="transfer_times" class="control-label col-lg-2">过户次数</label>
                                        <div class="col-lg-10">
                                            <input class="form-control " id="transfer_times" name="data[transfer_times]" value="<?=$vehicleinfo['transfer_times']?>" type="text" />
                                        </div>
                                    </div>
                                    <div class="form-group ">
                                        <label for="fixprice" class="control-label col-lg-2">一口价</label>
                                        <div class="col-lg-10">
                                            <input class="form-control " id="fixprice" name="data[fixprice]" value="<?=$vehicleinfo['fixprice']?>" type="text" />
                                        </div>
                                    </div>
                                    <div class="form-group ">
                                        <label for="status" class="control-label col-lg-2">状态</label>
                                        <div class="col-lg-10">
                                            <input class="form-control " id="status" name="data[status]" value="<?=$vehicleinfo['status']?>" type="text" />
                                        </div>
                                    </div>
                                    <div class="form-group ">
                                        <label for="popularity_index" class="control-label col-lg-2">人气指数</label>
                                        <div class="col-lg-10">
                                            <input class="form-control " id="popularity_index" name="data[popularity_index]" value="<?=$vehicleinfo['popularity_index']?>" type="text" />
                                        </div>
                                    </div>
                                    <div class="form-group ">
                                        <label for="dial_index" class="control-label col-lg-2">拨号指数</label>
                                        <div class="col-lg-10">
                                            <input class="form-control " id="dial_index" name="data[dial_index]" value="<?=$vehicleinfo['dial_index']?>" type="text" />
                                        </div>
                                    </div>
                                    <div class="form-group ">
                                        <label for="score" class="control-label col-lg-2">会员积分</label>
                                        <div class="col-lg-10">
                                            <input class="form-control " id="score" name="data[score]" value="<?=$vehicleinfo['score']?>" type="text" />
                                        </div>
                                    </div>
                                    <div class="form-group ">
                                        <label for="opr_user" class="control-label col-lg-2">发布人员编号</label>
                                        <div class="col-lg-10">
                                            <input class="form-control " id="opr_user" name="data[score]" value="<?=$vehicleinfo['opr_user']?>" type="text" />
                                        </div>
                                    </div>
<!--                                    /*     "vehicleimgs": "车辆照片json格式"-->
<!--                                    *     "weixinimg": "微信二维码地址"-->

                                    <div class="form-group">
                                        <div class="col-lg-offset-2 col-lg-10">
                                            <button class="btn btn-danger" type="submit">Save</button>
                                            <button class="btn btn-default" type="button">Cancel</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </section>
                </div>
            </div>
            <!-- page end-->
        </section>
    </section>
    <!--main content end-->
    <!--footer start-->
<footer class="site-footer">
    <div class="text-center">
        2019 &copy; 上海雅速企业管理咨询有限公司 技术支持
        <a href="#" class="go-top">
            <i class="fa fa-angle-up"></i>
        </a>
    </div>
</footer>
<!--footer end-->
</section>

<!-- js placed at the end of the document so the pages load faster -->
<script src="/static/admin/js/jquery.js"></script>
<script src="/static/admin/js/bootstrap.min.js"></script>
<script class="include" type="text/javascript" src="/static/admin/js/jquery.dcjqaccordion.2.7.js"></script>
<script src="/static/admin/js/jquery.scrollTo.min.js"></script>
<script src="/static/admin/js/jquery.nicescroll.js" type="text/javascript"></script>
<script type="text/javascript" src="/static/admin/js/jquery.validate.min.js"></script>
<script src="/static/admin/js/respond.min.js" ></script>

<!--right slidebar-->
<script src="/static/admin/js/slidebars.min.js"></script>

<!--common script for all pages-->
<script src="/static/admin/js/common-scripts.js"></script>

<!--script for this page-->
<script src="/static/admin/js/form-validation-script.js"></script>


</body>
</html>
