<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019\5\6 0006
 * Time: 22:38
 */

namespace app\api\controller;

use think\Controller;

class Base extends Controller
{

}