<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019\5\8 0008
 * Time: 2:30
 */

namespace app\api\controller;
use think\Request;

class User extends Base
{
    public function index(Request $request){
        echo "in";
    }

}