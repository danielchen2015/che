<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019\5\6 0006
 * Time: 22:18
 */

namespace app\admin\model;

use think\Model;

class Base extends Model
{

}