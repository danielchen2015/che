<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019\5\7 0007
 * Time: 23:16
 */

namespace app\admin\controller;


use think\Request;

class Index extends Base
{
    public function Index(Request $request)
    {
        return view();
    }

}